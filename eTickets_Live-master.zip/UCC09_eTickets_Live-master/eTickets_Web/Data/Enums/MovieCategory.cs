﻿namespace eTickets_Web.Data.Enums
{
    public enum MovieCategory
    {
        // Mopvie kategorileri listesi enum yapısı şeklinde tutulacak

        // normalde enum yapısı index değerini 0 dan tutar ..ama ben 1 den başlamasını istiyorum ki ilişkilendirmelere girecek

        Action = 1,
        Comedy,
        Drama,
        Documentary,
        Cartoon,
        Horror

    }
}
