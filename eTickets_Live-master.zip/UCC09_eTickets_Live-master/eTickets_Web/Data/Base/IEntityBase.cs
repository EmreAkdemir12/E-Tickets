﻿namespace eTickets_Web.Data.Base
{
    public interface IEntityBase
    {
        // Modellere taban teşkil edecek Interface
        int Id { get; set; }

    }
}
