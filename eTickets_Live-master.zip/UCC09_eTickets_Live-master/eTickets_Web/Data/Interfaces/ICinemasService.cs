﻿using eTickets_Web.Data.Base;
using eTickets_Web.Models;

namespace eTickets_Web.Data.Interfaces
{
    public interface ICinemasService : IEntityBaseRepository<Cinema>
    {
    }
}
